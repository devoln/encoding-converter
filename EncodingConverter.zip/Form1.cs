﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EncodingConverter
{
    public partial class Form1 : Form
    {
        static string[] encodingNames = new string[]
        {
            "UTF-8 без BOM",
            "UTF-8 с BOM",
            "UTF-16 LE",
            "UTF-16 BE",
            "UTF-32 LE",
            "UTF-32 BE",
            "CP1251",
            "KOI8-R",
            "KOI8-U"
        };

        static Encoding[] encodings = new Encoding[]
        {
            new UTF8Encoding(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true),
            Encoding.UTF8,
            Encoding.Unicode,
            Encoding.BigEndianUnicode,
            Encoding.UTF32,
            new UTF32Encoding(true, true),
            Encoding.GetEncoding(1251, new EncoderReplacementFallback("?"), new DecoderReplacementFallback("?")),
            Encoding.GetEncoding(20866, new EncoderReplacementFallback("?"), new DecoderReplacementFallback("?")),
            Encoding.GetEncoding(21866, new EncoderReplacementFallback("?"), new DecoderReplacementFallback("?"))
        };

        private Encoding GetEncodingByName(string name)
        {
            for (int i = 0; i < encodings.Length; i++)
                if (encodingNames[i]==name) return encodings[i];
            return null;
        }


        public Form1()
        {
            InitializeComponent();

            convertBtn.Enabled = false;
            analyzeBtn.Enabled = Directory.Exists(pathTextBox.Text.Trim());
            Form1_Resize(this, null);
        }


        private void RunProcess(string path, Encoding newEncoding)
        {
            var files = filterTextBox.Text.Split('|').SelectMany(filter => System.IO.Directory.GetFiles(path, filter, subdirCheck.Checked ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly));
            foreach (var file in files)
            {
                string oldEncodingName="";
                string result = "ОК";
                try
                {
                    Program.ProcessFile(file, ref oldEncodingName, newEncoding);
                    if (newEncoding == null) result = "";
                    else if (oldEncodingName == null) result = "Пропущен";
                }
                catch (IOException) { result = "Ошибка доступа"; }
                catch (UnauthorizedAccessException) { result = "Ошибка доступа"; }
                
                resultListView.Items.Add(new ListViewItem(new string[] { file, oldEncodingName, result}));
            }
        }

        private void browseBtn_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog(this);
            pathTextBox.Text = folderBrowserDialog1.SelectedPath;
        }

        private void pathTextBox_TextChanged(object sender, EventArgs e)
        {
            convertBtn.Enabled = false;
            analyzeBtn.Enabled = Directory.Exists(pathTextBox.Text.Trim());
        }

        private void analyzeBtn_Click(object sender, EventArgs e)
        {
            resultListView.Items.Clear();
            RunProcess(pathTextBox.Text, null);
            convertBtn.Enabled = true;
        }

        private void convertBtn_Click(object sender, EventArgs e)
        {
            resultListView.Items.Clear();
            RunProcess(pathTextBox.Text, GetEncodingByName(encodingSelector.Text));
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            resultListView.Width = Size.Width - resultListView.Location.X - 24;
            resultListView.Height = analyzeBtn.Location.Y - resultListView.Location.Y - 12;
            pathTextBox.Width = Size.Width - pathTextBox.Location.X - 96;
            filterTextBox.Width = subdirCheck.Location.X-filterTextBox.Location.X-12;
        }

        private void filterTextBox_TextChanged(object sender, EventArgs e)
        {
            convertBtn.Enabled = false;
        }

        private void subdirCheck_CheckedChanged(object sender, EventArgs e)
        {
            convertBtn.Enabled = false;
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, "Описание:\nПрограмма для преобразования кодировок текстовых файлов.\nВерсия: 1.0 beta\nПлатформа: .NET Framework 3.5\nЛицензия: MIT\n\n"+
                "Автор:\nВольнов Александр (gammaker)\n\nЕсли вам понравилась эта программа,\nпожалуйста, пожертвуйте\nЯндекс.Деньги: 410011926720740",
                "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
